select CategoryName,count(P.Id),round(avg(UnitPrice),2),min(UnitPrice),max(UnitPrice),sum(UnitsOnOrder)
from Product P, Category C
where P.CategoryId = C.Id
group by CategoryId
having count(*) > 10
order by CategoryId;


