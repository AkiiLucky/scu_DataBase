with P as (
	select Id, ProductName
	from Product
	where Id in (
		select ProductId
		from Customer C
		inner join `Order` O on O.CustomerId = C.Id
		inner join OrderDetail OD on OD.OrderId = O.Id
		where CompanyName = 'Queen Cozinha' and date(OrderDate) = '2014-12-25'
	)
	order by Id
),
T as (
	select row_number() over (order by P.Id asc) num, P.ProductName  --计算行号
	from P
),
PNs as (
	select num,ProductName
	from T
	where num = 1
	union all
	select T.num,PNs.ProductName||','||T.ProductName
	from T inner join PNs 
	on T.num = PNs.num + 1 --行号加1表示下一行
)
select ProductName from PNs
order by num desc 
limit 1;



