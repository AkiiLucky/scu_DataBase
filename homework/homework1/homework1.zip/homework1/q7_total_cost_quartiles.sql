select CompanyName,CustomerId,totalExpenditures
from (
	select ifnull(CompanyName,'MISSING_NAME') CompanyName,Ct.CustomerId, totalExpenditures,
		ntile(4) over (
		order by totalExpenditures
		) ntiles
	from (
		select CustomerId,sum(UnitPrice*Quantity) totalExpenditures
		from `Order` O, OrderDetail OD
		where O.Id = OD.OrderId
		group by CustomerId
		) Ct 
	left join  Customer C 
	on C.Id = Ct.CustomerId
)
where ntiles = 1
order by totalExpenditures
