select P.ProductName, C.CompanyName, C.ContactName
from Product P, Customer C, (
	select P1.Id, O1.CustomerId, O1.OrderDate
	from Product P1,OrderDetail OD1,`Order` O1
	where P1.Id = OD1.ProductId and OD1.OrderId = O1.Id and P1.Discontinued = 1 and not exists (
		select P2.Id, O2.CustomerId, O2.OrderDate
		from Product P2,OrderDetail OD2,`Order` O2
		where P2.Id = OD2.ProductId and OD2.OrderId = O2.Id and P2.Discontinued = 1 and P2.Id = P1.Id and O2.OrderDate < O1.OrderDate
		) 
	) t
where P.Id = t.Id and C.Id = t.CustomerId
order by P.ProductName
