select RegionDescription,FirstName,LastName,max(BirthDate) BirthDate
from Employee E 
inner join (
	select distinct EmployeeId,RegionId
	from EmployeeTerritory ET
	inner join Territory T
	on ET.TerritoryId = T.Id
) ER
on E.Id = ER.EmployeeId
inner join Region R
on R.Id = ER.RegionId
group by ER.RegionId
order by ER.RegionId


