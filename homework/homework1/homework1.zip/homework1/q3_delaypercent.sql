select S.CompanyName ShipperCompanyName, t.delaypercent
from `Shipper` S,
(select t1.ShipVia , round(t1.delayNum*1.0/t2.allNum*100,2) delaypercent
from
(select ShipVia,count(*) delayNum
from `Order`
where ShippedDate > RequiredDate
group by ShipVia) t1,
(select ShipVia,count(*) allNum
from `Order`
group by ShipVia) t2
where t1.ShipVia = t2.ShipVia) t
where t.ShipVia = S.Id
order by t.delaypercent desc;










