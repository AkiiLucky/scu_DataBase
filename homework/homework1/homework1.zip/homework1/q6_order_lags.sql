select *,round((julianday(OrderDate) - julianday(PreviousOrderDate)),2) lagTime
from (
	select Id,OrderDate,
	  lag(OrderDate,1,OrderDate) OVER (
	    order by OrderDate asc
	  ) PreviousOrderDate
	from `Order`
	where CustomerId = 'BLONP'
	order by OrderDate
	limit 0,10
);
